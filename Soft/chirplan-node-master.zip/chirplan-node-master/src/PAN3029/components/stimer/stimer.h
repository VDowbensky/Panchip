/*******************************************************************************
 * @note Copyright (C) 2011-2022， Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef __STIMER_H__
#define __STIMER_H__

#include <stdint.h>
#include <stdlib.h>
#include "ddl.h"

#define STIMER_MODE_ONESHOT  0
#define STIMER_MODE_REPEAT   1

//软件定时器，如果在不使用contiki的情况下可使用
typedef void (*stimer_cb_t)(void *ptr);
typedef  uint32_t clock_time_t;

typedef struct stimer {
  struct stimer *next;
  clock_time_t start;
  clock_time_t interval;
  stimer_cb_t func;
  void *ptr;
  int repeat;
}ctimer_t;

void stimer_init(void);
void stimer_process(void);
void stimer_set(struct stimer *s, clock_time_t t, int repeat, stimer_cb_t func, void *ptr);
void stimer_stop(struct stimer *s);
uint8_t stimer_expired(struct stimer *s);
void stimer_restart(struct stimer *s);

#endif
