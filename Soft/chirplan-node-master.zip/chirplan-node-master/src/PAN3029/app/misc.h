/*******************************************************************************
 * @note Copyright (C) 2011-2022, Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef _MISC_H_
#define _MISC_H_

char char_toupper(char c);
void str_toupper(char *str, int len);
int StrToHex(u8 *pbDest, char *pszSrc, int nLen);
void HexToStr(char *pszDest, u8 *pbSrc, int nLen);

#endif

