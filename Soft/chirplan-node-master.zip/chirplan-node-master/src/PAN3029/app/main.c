/*******************************************************************************
 * @note Copyright (C) 2011-2022, Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#include "user.h"
#include "ddl.h"
#include "flash.h"
#include "gpio.h"
#include "hardware.h"
#include "easyflash.h"
#include "at.h"
#include "stimer.h"
#include "sysctrl.h"
#include "service_nodemode.h"
#include "aes_ecb.h"
#include "chirplan.h"
#include "service_pt.h"
#include "service_net.h"
#include "reset.h"
#ifdef USBDONGLE
#include "ds18b20.h"
#include "hal_pwm.h"
#endif

int32_t main(void)
{
	__disable_irq();
	Reset_ClearFlagAll();
	Reset_RstPeripheralAll();

	hw_gpio_cfg();
	hw_pll_init();

#ifdef EF_USING_ENV
	if ( easyflash_init() == EF_NO_ERR )
	{
		/* restore user settings */
		node_restore_setting();
	}
#endif

	/* 
	 * After the application is successfully started, it should write 0 at address 0xFFFC. In this way, 
	 * bootloader can know that the application has been successfully started after the next startup, 
	 */
	Flash_WriteByte(0xFFFC, 0x00);

#ifdef DDL_UART_DMA_YES
	app_uart0_dma_cfg();
#endif
	
	hw_uart_gpio_init();

	hw_uart_cfg();

	hw_spi_cfg();

	hw_rng_cfg();

	/* for delay function */
	hw_timer0_cfg();

	/* for uart packing timeout */
	hw_timer1_cfg();

	SystemCoreClockUpdate();

	/* for stimer */
	SysTick_Config(SystemCoreClock/1000); //1ms interrupt period
	hw_timer2_cfg();

	pc_debug("SystemCoreClock:%uMHz", SystemCoreClock/1000000);

	/* soft timer init */
	stimer_init(); 

#ifdef USBDONGLE
	Hal_Pwm_Init();	
	PWM_Set_RGB(0x0f0f0f);//��ɫ�ƣ���ʱ
//	delay1ms(1000);

	if( !DS18B20_Init() )
		pc_debug("DS18B20_Init ok\n"); 
#endif
    /* node mode task init */
    nm_init();

    /* aux init level is setted to low */
    aux_level_set(AUX_INIT, LEVEL_INACTIVE);
    
    __enable_irq();
	extern node_config_t node_config;
    printf("demo ok:%x\r\n",node_config.node_id);
    while ( 1 )
    {
        /* at server process */
        at_server_process();
        
        /* pass through process */
        pt_process();
        
        /* net process */
        net_process();

        /* node mode process */
        nm_process();

        /* stimer process */
        stimer_process();
    }
}

/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
 
