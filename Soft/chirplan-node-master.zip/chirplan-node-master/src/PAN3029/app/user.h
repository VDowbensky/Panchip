/*******************************************************************************
 * @note Copyright (C) 2011-2022, Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef _USER_H
#define _USER_H

#include "ddl.h"
#include "timer3.h"
#include "userdef.h"
#include "flash.h"
#include "uart.h"

/* Micro Definition */
#define SET_BIT(REG, BIT)     ((REG) |= (BIT))

#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))

#define READ_BIT(REG, BIT)    ((REG) & (BIT))

#define START_TASK_STK_SIZE           128
#define START_TASK_PRIO               2

#define PT_TASK_STK_SIZE              128
#define PT_TASK_PRIO                  3

#define AT_TASK_STK_SIZE              128
#define AT_TASK_PRIO                  4

#define NM_TASK_STK_SIZE              64
#define NM_TASK_PRIO                  5

/* Enum */
enum
{
    UART_IDLE = 0,
    UART_RECEIVING,
    UART_SUCCESS,
    UART_TRANSMITTING,
};

typedef struct
{
    u32 freq;
    u8 cr;
    u8 bw;
    u8 sf;
    u8 pwr;
    u8 crc;
    u8 ldr;
    u8 modemMode;
    u16 preamble;
    u8 dcdc;
}rf_config_t;

/* Variable Declaration */
extern rf_config_t pn3029_config;

/* Function Declaration */
extern void user_set_rf_para(rf_config_t *p);
extern int node_store_setting(void);
extern int node_restore_setting(void);
extern int node_delete_setting(void);
extern int get_package_time(rf_config_t *p, int payload_len);

#endif

