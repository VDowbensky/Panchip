/*******************************************************************************
 * @note Copyright (C) 2011-2022, Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef __HAL_PWM_H__
#define __HAL_PWM_H__

#include "timer3.h"
#include "gpio.h"

void Hal_Pwm_Init(void);
void PWM_Set_RGB(uint32_t Value);

#endif
