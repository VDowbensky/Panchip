/*******************************************************************************
 * @note Copyright (C) 2011-2022， Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef _PN_ATCMD_H_
#define _PN_ATCMD_H_

#include "userdef.h"
#include "chirplan.h"

#define STRING_ON     "ON"
#define STRING_OFF    "OFF"

#define WAKEUP_TIME_MIN   100
#define WAKEUP_TIME_MAX   5000

#define UART_INTERVAL_MIN   2
#define UART_INTERVAL_MAX   100

#define RF_PREAMTIME_MIN    0
#define RF_PREAMTIME_MAX    5000

#define RF_SF_MIN    7
#define RF_SF_MAX    12

#define RF_TXPOWER_MIN    0
#define RF_TXPOWER_MAX    30


#define PIN_AUX_TIME_MIN    0
#define PIN_AUX_TIME_MAX    100


typedef enum
{
    WORKMODE_PT,   //pass through mode
    WORKMODE_NET,  //net mode
    WORKMODE_MAX
}workmode_t;

typedef enum
{
    PT_CLASS_PT,   //mode:point to all
    PT_CLASS_P2P,   //mode:point to point
    PT_CLASS_MAX
}pt_class_t;

/*
 * 功耗模式，仅对PT和P2P模式有效
 */
typedef enum
{
    PWRMODE_RUN, //full run
    PWRMODE_LSR, //timed wakeup
    PWRMODE_ALL, //deepsleep
    PWRMODE_MAX
}lp_mode_t;

/*
 * 节点配置参数结构体
 */
typedef struct
{
    workmode_t work_mode;  //node workmode
    pt_class_t pt_class;   //work class of pt
    net_class_t net_class; //work class of net
    u32 node_id;           //node id:1(default)
    u32 gw_id;             //gateway id, reserved
	u16 app_id;            //app id:1(default)
    u32 channel;           //radio channel
    u32 channel_up[8];     //radio channel0, up link channel
    u32 channel_down[8];   //radio channel1, down link channel
    u16 rate;              //radio rate:1:268bps/2:488bps/3:537bps/4:878bps/5:977bps/6:1758bps/7:3125bps/8:6250bps/9:10937bps/10:21875bps
    u16 preamtime;         //preamble time,100-5000ms,0ms(default)
    u32 wakeup_time;       //wake-up interval,100-5000ms,0ms(default)
    u16 rf_rx_timeout;     //rf receive timeout in timed wakeup mode, unit:ms
	u16 rf_rx_window;      //rf receive window time, unit:ms
    u32 uart_baudrate;     //uart baudrate: 115200(default)
    u16 uart_databit;      //uart databit : 8(default)
    u16 uart_stopbit;      //uart stopbit: 1(default)
    u16 uart_parity;       //uart parity: 0(default)
    u16 uart_interval;     //uart packing interval: 5ms(default)
	u16 cad_check_en;      //check rf busy state before sending datas
    bool aes_enable;       //encrypt enable: ON/OFF
    u8 aes_key[16];        //encrypt key:16byte,format:hex
    u8 addr0;              //node address0
    u8 addr1;              //node address1
    u16 aux_mode;          //aux pin behavior mode:AUX_MODE_EMPTY/AUX_MODE_FULL
    u16 aux_head_time;     //aux head delay time:ms
    u16 aux_tail_time;     //aux tail delay time:ms
    u16 net_dack_enbale;   //net data ack enable
    u16 at_ack_type;       //at cmd response type
}node_config_t;

#pragma pack(1)
typedef struct
{
    u8  rate_scale;    //rate scale:1~10
    u16 nominal_rate;  //unit:bps
    u8  cr;
    u8  sf;
    u8  bw;
}table_rate_t;
#pragma pack()

#endif

