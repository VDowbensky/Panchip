/*******************************************************************************
 * @note Copyright (C) 2011-2022, Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef _DS18B20_H_
#define _DS18B20_H_

#include "hardware.h"


/*  DS18B20时钟端口、引脚定义 */
#define DS18B20_PORT 			GpioPortA  
#define DS18B20_PIN 			GpioPin8


//IO操作函数									   
#define	DS18B20_DQ_OUT_SET() 	Gpio_SetIO(GpioPortA,GpioPin8) //数据端口	
#define	DS18B20_DQ_OUT_CLR() 	Gpio_ClrIO(GpioPortA,GpioPin8) //数据端口

#define	DS18B20_DQ_IN()  		Gpio_GetInputIO(DS18B20_PORT,DS18B20_PIN) 	 //数据端口	 
   	
float DS18B20_GetTemperture(void);	//获取温度
void DS18B20_Start(void);			//开始温度转换
void DS18B20_Write_Byte(u8 dat);	//写入一个字节
u8 DS18B20_Read_Byte(void);			//读出一个字节
u8 DS18B20_Read_Bit(void);			//读出一个位
u8 DS18B20_Check(void);				//检测是否存在DS18B20
void DS18B20_Reset(void);			//复位DS18B20   
u8 DS18B20_Init(void);
#endif

