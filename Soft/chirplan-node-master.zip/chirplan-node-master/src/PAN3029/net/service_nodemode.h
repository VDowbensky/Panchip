/*******************************************************************************
 * @note Copyright (C) 2011-2022, Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef _SERVICE_NODEMODE_H
#define _SERVICE_NODEMODE_H

#include "userdef.h"

#define NODE_MODE_OP_IO   0x0001 /* Node mode is operated by gpio */
#define NODE_MODE_OP_AT   0x0002 /* Node mode is operated by cmd */

typedef enum{
    NM_STATE_AT,    /* AT Mode State */
    NM_STATE_DATA,  /* DATA Mode State */
}nm_state_t;

typedef struct{
    nm_state_t state; /* Current mode state of node */
    u16 nodemode_op;  /* Current operation mode, which can be 
                         NODE_MODE_OP_IO or NODE_MODE_OP_AT. */
}nm_proc_t;

void nm_set_io_op(void);
void nm_set_at_op(void);
nm_state_t nm_get_state(void);
void nm_set_state(nm_state_t state);
void nm_enter_at_mode(void);
void nm_enter_data_mode(void);
void nm_process(void);
void nm_init(void);

#endif

