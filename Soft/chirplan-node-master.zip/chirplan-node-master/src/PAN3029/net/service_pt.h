/*******************************************************************************
 * @note Copyright (C) 2011-2022, Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#ifndef SERVICE_PT_H_
#define SERVICE_PT_H_

#include "ddl.h"
#include "timer3.h"
#include "userdef.h"
#include "flash.h"
#include "uart.h"
#include "pn_atcmd.h"
#include "stimer.h"
#include <stdbool.h>

#define PT_DEBUG

#ifdef PT_DEBUG
    #define pt_debug pc_debug
#else 
    #define pt_debug(format,...)
#endif

#define PT_EVT_NONE              0x00000000
#define PT_EVT_RF_TX_DONE        0x00000001
#define PT_EVT_RF_RX_DONE        0x00000002
#define PT_EVT_UART_TX_DONE      0x00000004
#define PT_EVT_UART_RX_DONE      0x00000008
#define PT_EVT_RF_TX_TIMEOUT     0x00000010
#define PT_EVT_RF_RX_TIMEOUT     0x00000020
#define PT_EVT_RF_CRC_ERR        0x00000040
#define PT_EVT_SETB_ACTIVE       0x00000080
#define PT_EVT_SETB_INACTIVE     0x00000100

#define PT_BUF_SIZE    256

#define PT_SWITCH_STATE_IDLE  0  /* idle state */
#define PT_SWITCH_STATE_WACK  1  /* wait ack state */


enum pt_status
{
    PT_STATUS_UNINITIALIZED = 0,
    PT_STATUS_INITIALIZED,
    PT_STATUS_CLI,
};
typedef enum pt_status pt_status_t;

typedef enum
{
    PT_STATE_INIT,
    PT_STATE_IDLE,
    PT_STATE_RF_TX,
    PT_STATE_RF_RX,
    PT_STATE_UART_TX,
    PT_STATE_SLEEP,
}pt_state_t;

#pragma pack(2)
typedef struct pt_msg
{
    int flag;        /* message flag */
    u16 len;         /* payload length */
    u8  addr0;       /* only used by PT_CLASS_P2P */
    u8  addr1;       /* only used by PT_CLASS_P2P */
    u8  buf[PT_BUF_SIZE];   /* payload */
}pt_msg_t;

typedef struct pt_aes
{
    //int len;        /* payload length */
    u8 res[3];
    u8 len;                /* length of encrypt payload */
    u8 buf[PT_BUF_SIZE];   /* encrypt payload */
}pt_aes_t;

typedef struct
{
    pt_status_t status;
    u32 count;
    u32 evt;
    pt_state_t state;
    ctimer_t stimer_rf_tx;     /* soft timer for rf tx */
    ctimer_t stimer_rf_rx;     /* soft timer for rf rx */
    pt_msg_t uart_msg;
    pt_msg_t rf_msg;
    pt_aes_t aes_msg;
    int pt_at_switch;
    int cmd_sleep;
    bool rtc_on;
}pt_proc_t;
#pragma pack()

void pt_init(void);
void pt_process(void);
void pt_delete(void);
void pt_io_set_evt(void);

#endif

