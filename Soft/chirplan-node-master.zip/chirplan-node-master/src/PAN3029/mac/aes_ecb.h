#ifndef __AES_ECB_H__
#define __AES_ECB_H__

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define AES_BYTE_ALIGNMENT 0x0F

int app_aes_get_align_len(int len);

int encrypt(uint8_t *encrypt, uint8_t *encrypted, uint8_t *key, int keylen, int32_t num);
int decrypt(uint8_t *decrypt, uint8_t *decrypted, uint8_t *key, int keylen, int32_t num);

#endif
