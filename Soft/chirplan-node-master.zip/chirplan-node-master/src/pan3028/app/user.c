/*******************************************************************************
 * @note Copyright (C) 2011-2022， Shanghai Panchip Microelectronics Co., Ltd. 
 * @SPDX-License-Identifier: Apache-2.0
 * @history - V0.1, 2022-09-28
*******************************************************************************/
#include "hardware.h"
#include "pan3028.h" 
#include "radio.h"
#include "spi.h"
#include "at.h"
#include "user.h"
#include "service_pt.h"
#include "flash.h"
#include "easyflash.h"
#include "service_nodemode.h"

extern u32 uart_baudrate;
extern u32 uart_packing_interval;
extern rf_config_t pn3028_config;
extern node_config_t node_config;
extern bool g_at_ack_type;

void user_set_rf_para(rf_config_t *p)
{
    PAN3028_set_mode(PAN3028_MODE_STB3);
    
    rf_set_para(RF_PARA_TYPE_FREQ, p->freq);
    rf_set_para(RF_PARA_TYPE_CR, p->cr);
    rf_set_para(RF_PARA_TYPE_BW, p->bw);
    rf_set_para(RF_PARA_TYPE_SF, p->sf);
    rf_set_para(RF_PARA_TYPE_TXPOWER, p->pwr);
    rf_set_para(RF_PARA_TYPE_CRC, p->crc);
    
    rf_set_ldr(p->ldr);
    PAN3028_set_preamble(p->preamble);
    rf_set_dcdc_mode(p->dcdc);
}

int get_package_time(rf_config_t *p, int payload_len)
{
    const float bw_table[10] = {0,0,0,0,0,0,62.5,125,250,500};

    if(p->bw < 6 ||p->bw > 9)
    {
        return 0;
    }

    int msg_format = 1;                 //message format
    float symbol_len = (float)(1<<p->sf)/bw_table[p->bw]; //symbol length
    float preamble_time;                //preamble time:ms
    float payload_time = 0;             //payload time:ms
    float total_time;                   //total time:ms

    if (p->sf < 7)
    {
        preamble_time = (p->preamble+6.25f)*symbol_len;
    }
    else
    {
        preamble_time = (p->preamble+4.25f)*symbol_len;
    }

    if (payload_len > 0)
    {
        payload_time = ceil((float)(payload_len*8-p->sf*4+28-(1-msg_format)*20+16)/((p->sf-p->ldr*2)*4));
        payload_time = payload_time*(p->cr+4);
        payload_time = payload_time+8;
        payload_time = payload_time*symbol_len;        
    }

    total_time = preamble_time+payload_time;
    
    return (int)total_time;
}


#ifdef EF_USING_ENV
//删除所有配置参数
int node_delete_setting(void)
{
    ef_del_env("rf_config");
    ef_del_env("node_config");
    
    return 0;
}

//保存当前配置参数
int node_store_setting(void)
{
    size_t ret;
    
    ret = ef_set_env_blob("rf_config", &pn3028_config, sizeof(pn3028_config));
    if ( ret == EF_NO_ERR )
    {
        pc_debug("set rf_config ok");
    }
    else
    {
        pc_debug("set rf_config fail");
    }

    ret = ef_set_env_blob("node_config", &node_config, sizeof(node_config));
    if ( ret == EF_NO_ERR )
    {
        pc_debug("set node_config ok");
    }
    else
    {
        pc_debug("set node_config fail");
    }

    return 0;
}

//恢复配置参数
int node_restore_setting(void)
{
    size_t ret, len;
    
    ret = ef_get_env_blob("rf_config", &pn3028_config, sizeof(pn3028_config), &len);
    if ( ret )
    {
        //pc_debug("get rf_config ok");
    }
    else
    {
        //pc_debug("get rf_config fail");
    }
    
    ret = ef_get_env_blob("node_config", &node_config, sizeof(node_config), &len);
    if ( ret )
    {
        //pc_debug("get node_config ok");
    }
    else
    {
        //pc_debug("get node_config fail");
    }
    
    if ( node_config.uart_baudrate != 9600 \
         && node_config.uart_baudrate != 19200 \
         && node_config.uart_baudrate != 38400 \
         && node_config.uart_baudrate != 57600 \
         && node_config.uart_baudrate != 115200 )
    {
        node_config.uart_baudrate = 115200;
    }

    if ( node_config.uart_interval < 2 
         || node_config.uart_interval > 50 )
    {
        node_config.uart_interval = 5;
    }
    
    uart_baudrate = node_config.uart_baudrate;
    uart_packing_interval = node_config.uart_interval;
    g_at_ack_type = node_config.at_ack_type;
    
    return 0;
}
#endif

