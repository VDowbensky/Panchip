/************************************************************************************************/
/**
* @file               main.c
* @author             MCU Ecosystem Development Team
* @brief              ��ʾ��չʾ��SNģ���÷���
*                     
*
**************************************************************************************************
* @attention
* Copyright (c) CEC Huada Electronic Design Co.,Ltd. All rights reserved.
*
**************************************************************************************************
*/

/*------------------------------------------includes--------------------------------------------*/
#include "main.h"
#include "common.h"
#include "SN_GPIO.h"
#include "SN_ADC.h"
#include "SN_PWM.h"
#include "SN_EXIT.h"
#include "SN_TIM3_INIT.h"
#include "SN_TIM1_INIT.h"
#include "SN_UART.h"
#include "SN_FLASH.h"
#include "SN_RCC.h"
#include "SN_SPI.h"
#include "SN_DDQ.h"
#include "i2c_bsp.h"
#include "SN_STOP.h"
#include <stdio.h>
#include "myRadio.h"
/*------------------------------------------functions-------------------------------------------*/
  
uint16_t ADC_VAL = 0;
float MCU_VDD = 0;

void rfRx_callback(uint8_t status, rfRxPacket_ts packet)
{
    switch (status)
    {
        case RX_STA_SECCESS:
        {
            myRadio_receiver();
        }
        break;
        case RX_STA_TIMEOUT:
        {
            myRadio_receiver();
        }
        break;
        case RX_STA_PAYLOAD_ERROR:
        {
            myRadio_receiver();
        }
        break;
        case TX_STA_SECCESS:
        {
			myRadio_receiver();
        }
        break;
        default:
            break;
    }
}
uint32_t sendTimeout = 0;
int main(void)
{  
    SN_SYSCLK_set(SYSCLK_48MHZ);                  //����ϵͳʱ��Ϊ48MHZ
    std_delay_init();                             //��ʼ����ʱ������ʱ��ʹ�õδ�ʱ��ʵ�ֵģ�
    myRadio_init(0, rfRx_callback);
    RF_SetPreamLen(50);
    // myRadio_setFrequency(SET_RF_FREQ_HZ(rfBaseFreqList[deviceInfor.chipType], deviceInfor.rfChannel, deviceInfor.channelStep));
    // myRadio_setTxPower(rfTxPowerList[deviceInfor.txPower]);
    // myRadio_setRfParams(deviceInfor.rf_sf, deviceInfor.rf_bw, deviceInfor.rf_cr);
    // myRadio_setSyncWord(0x45);
    
    // myRadio_receiver();
    // std_delayms(500);
    // myRadio_transmitArray("hello world", 10);		
	//   SN_ADC_IN_init(ADC_CHANNEL_4_PA7);            //��ʼ��ADC				 
	// 	SN_PWM_TIM1_OUT_Complementary(TIM1_CH2N_PA0); //���û���ͨ����ע��Ҫ���趨����ͨ���󣬲��ܳ�ʼ��pwm���
    // SN_PWM_TIM1_OUT_init(TIM1_CH2_PA1,1000);      //���ö�ʱ��3ͨ��1 �� ͨ��2 ���ռ�ձ�����1000�ķ��������io�ֱ���PA0 ,PA4
	//   SN_UART_init(UART1,9600, UART1_RX_PA4 ,UART1_TX_PA3 ); //��ʼ������
    while(1){
		std_delayms(1);		
		// SN_ADC_start();		                        //��ʱ�����SN_ADC_star()����ѯ����			
		// ADC_VAL = SN_ADC_Get_float(0);            //PA7ͨ����ѹֵ
		// MCU_VDD = SN_ADC_MCU_VDD();               //��ȡMCU�ĵ�ǰvdd��ѹ
        if (sendTimeout++ > 1000+rand()%100)
        {
            sendTimeout = 0;
            myRadio_transmitArray("hello world", 10);
        }
        
		myRadio_process();
	}
}
		





