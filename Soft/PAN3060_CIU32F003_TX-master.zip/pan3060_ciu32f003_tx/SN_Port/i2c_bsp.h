/************************************************************************************************/
/**
* @file               i2c_bsp.h
* @author             MCU Ecosystem Development Team
* @brief              I2C BSPͷ�ļ���
*
*
**************************************************************************************************
* @attention
* Copyright (c) CEC Huada Electronic Design Co.,Ltd. All rights reserved.
*
**************************************************************************************************
*/

/* ����ͷ�ļ��ظ����� */
#ifndef I2C_BSP_H
#define I2C_BSP_H

#include "ciu32f003_std.h"
#ifdef __cplusplus
extern "C" {
#endif

/*------------------------------------------includes--------------------------------------------*/


/*-------------------------------------------define---------------------------------------------*/
/* I2C��ʱ���� */
#define CLK_DELAY                       (16U)
#define ACK_DELAY                       (6U)      
#define USER_DELAY                      (5U)         //

/* I2C����ACK������ */
#define RET_ACK                         (0x00000000U)
#define RET_NACK                        (0x00000001U)

/* I2C������д���� */
#define REQ_WRITE                       (0U)
#define REQ_READ                        (1U)

/*-------------------------------------------  io_set  ------------------------------------------*/
#define    IIC_SCL_PA0  1U
#define    IIC_SCL_PA1	2U					 
#define    IIC_SCL_PA2  3U
#define    IIC_SCL_PA3  4U
#define    IIC_SCL_PA4  5U
#define    IIC_SCL_PA5  6U
#define    IIC_SCL_PA6  7U
#define    IIC_SCL_PA7	8U

#define    IIC_SCL_PB0  9U
#define    IIC_SCL_PB1  10U
#define    IIC_SCL_PB2  11U
#define    IIC_SCL_PB3  12U
#define    IIC_SCL_PB4  13U
#define    IIC_SCL_PB5  14U
#define    IIC_SCL_PB6  15U
#define    IIC_SCL_PB7	16U

#define    IIC_SCL_PC0  17U
#define    IIC_SCL_PC1	18U


#define    IIC_SDA_PA0  1U
#define    IIC_SDA_PA1	2U					 
#define    IIC_SDA_PA2  3U
#define    IIC_SDA_PA3  4U
#define    IIC_SDA_PA4  5U
#define    IIC_SDA_PA5  6U
#define    IIC_SDA_PA6  7U
#define    IIC_SDA_PA7  8U
						 
#define    IIC_SDA_PB0  9U
#define    IIC_SDA_PB1  10U
#define    IIC_SDA_PB2  11U
#define    IIC_SDA_PB3  12U
#define    IIC_SDA_PB4  13U
#define    IIC_SDA_PB5  14U
#define    IIC_SDA_PB6  15U
#define    IIC_SDA_PB7  16U
						 
#define    IIC_SDA_PC0  17U
#define    IIC_SDA_PC1	18U


#define    IIC_PULLUP_NULL   0U
#define    IIC_PULLUP	       1U


/*-------------------------------------------functions-�ڲ�iic�ӿ�-----------------------------------------*/
static void bsp_i2c_generate_start(void);
static void bsp_i2c_generate_stop(void);
static void bsp_i2c_generate_ack(uint32_t ack_type);
static uint32_t bsp_i2c_master_send_byte(uint8_t data);
static uint8_t bsp_i2c_master_receive_byte(void);

/*-------------------------------------------functions-----�û�iic�ӿ�-------------------------------------*/
void  SN_IIC_IO_set(uint8_t SCL_PIN_x ,uint8_t SDA_PIN_x ,uint8_t PULLUP ); //����iicҪʹ�õ�ͨ������
void  SN_IIC_slave(uint8_t iic_slave_id );                                 //���ôӻ�id
void  SN_IIC_ERROR_call(void (*error_call) (void));                         //����ͨ�Ŵ�����
void  bsp_i2c_master_send(uint8_t * g_tx_buffer , uint16_t BUFF_SIZE);      //������������
void  bsp_i2c_master_receive(uint8_t * g_rx_buffer,uint16_t BUFF_SIZE);     //������������











#ifdef __cplusplus
}
#endif

#endif /* I2C_BSP_H */

