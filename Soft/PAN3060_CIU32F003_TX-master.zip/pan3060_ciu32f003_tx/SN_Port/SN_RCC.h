#ifndef SN_RCC_H
#define SN_RCC_H
#include "ciu32f003_std.h"


#define   SYSCLK_8MHZ       RCC_SYSCLK_SRC_RCHDIV6
#define   SYSCLK_16MHZ      RCC_SYSCLK_SRC_RCHDIV3
#define   SYSCLK_48MHZ      RCC_SYSCLK_SRC_RCH
#define   SYSCLK_32KHZ      RCC_SYSCLK_SRC_RCL

#define MOC_PA7_OUT    1U
#define MOC_PB1_OUT    2U
#define MOC_PB6_OUT    3U



void SN_SYSCLK_set(uint32_t SYSCLK_from);                                         //����ϵͳʱ��
void  SN_CLK_MOC(uint32_t PIN_X	, uint32_t  RCC_MCO_SRC, uint32_t  RCC_MCO_DIV_x);//��������Դ���



#endif
