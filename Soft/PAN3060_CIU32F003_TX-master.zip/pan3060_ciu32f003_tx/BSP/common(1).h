/************************************************************************************************/
/**
* @file               common.h
* @author             MCU Ecosystem Development Team
* @brief              COMMONͷ�ļ���
*                           
*
**************************************************************************************************
* @attention
* Copyright (c) CEC Huada Electronic Design Co.,Ltd. All rights reserved.
*
**************************************************************************************************
*/

/* ����ͷ�ļ��ظ����� */
#ifndef COMMON_H
#define COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

/*------------------------------------------includes--------------------------------------------*/
#include "ciu32f003_std.h"

/*-------------------------------------------define---------------------------------------------*/
/* LED IO��ض��� */
#define LED_GPIO_PORT            GPIOA
#define LED_PIN                  GPIO_PIN_5


/*-------------------------------------------functions------------------------------------------*/
void system_clock_config(void);
void gpio_init(void);

#ifdef __cplusplus
}
#endif

#endif /* COMMON_H */

