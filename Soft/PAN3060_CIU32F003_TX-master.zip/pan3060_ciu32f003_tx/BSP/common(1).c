/************************************************************************************************/
/**
* @file               common.c
* @author             MCU Ecosystem Development Team
* @brief              ͨ�ú�����������ص�����ʵ�ֺ�����
*
*
**************************************************************************************************
* @attention
* Copyright (c) CEC Huada Electronic Design Co.,Ltd. All rights reserved.
*
**************************************************************************************************
*/

/*------------------------------------------includes--------------------------------------------*/
#include "common.h"

/*------------------------------------------functions-------------------------------------------*/
/**
* @brief  ϵͳʱ������
* @retval ��
*/
void system_clock_config(void)
{
    /* ����Flash�����ʵȴ�ʱ�� */
    std_flash_set_latency(FLASH_LATENCY_1CLK);

    /* ʹ��RCH */
    std_rcc_rch_enable();
    while(std_rcc_get_rch_ready() != RCC_CSR1_RCHRDY);
  
    /* ����ϵͳʱ��ԴΪRCH */
    std_rcc_set_sysclk_source(RCC_SYSCLK_SRC_RCH);
    while(std_rcc_get_sysclk_source() != RCC_SYSCLK_SRC_STATUS_RCH);

    /* ����AHB��Ƶ���� */
    std_rcc_set_ahbdiv(RCC_HCLK_DIV1);
    /* ����APB��Ƶ���� */
    std_rcc_set_apbdiv(RCC_PCLK_DIV1);
    /* ����ϵͳʱ��ȫ�ֱ��� */
    SystemCoreClock = RCH_VALUE;
}

/**
* @brief  GPIO��ʼ��
* @retval ��
*/
void gpio_init(void)
{
    std_gpio_init_t gpio_config = {0};

    /* ʹ��LED��Ӧ��GPIOʱ�� */
    std_rcc_gpio_clk_enable(RCC_PERIPH_CLK_GPIOB);
		std_rcc_gpio_clk_enable(RCC_PERIPH_CLK_GPIOA);

    /* ����LED��IO */
    gpio_config.pin = LED_PIN;
    gpio_config.mode = GPIO_MODE_OUTPUT;
    gpio_config.pull = GPIO_NOPULL;
    gpio_config.output_type = GPIO_OUTPUT_PUSHPULL;
		std_gpio_init(GPIOA, &gpio_config);
    std_gpio_set_pin(LED_GPIO_PORT,LED_PIN);
		
		gpio_config.pin = GPIO_PIN_6;              //PA2
		gpio_config.mode = GPIO_MODE_INPUT;
    gpio_config.pull = GPIO_PULLDOWN;
    std_gpio_init(GPIOB, &gpio_config);
		
}
