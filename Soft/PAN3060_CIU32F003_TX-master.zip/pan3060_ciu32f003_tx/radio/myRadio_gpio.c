#include "myRadio_gpio.h"
#include "SN_SPI.h"

RADIO_GPIO_CALLBACK gpioCallback;
int spiMosiMode = 0;
//---------------------------射频SPI驱动部分---------------------
void BOARD_SPI_NSS_H(void)
{
    std_spi_set_nss_output(SPI_NSS_OUTPUT_HIGH);
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_CSN, 1);
}
void BOARD_SPI_NSS_L(void)
{
    std_spi_set_nss_output(SPI_NSS_OUTPUT_LOW);
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_CSN, 0);
}
void BOARD_SPI_SCK_H(void)
{
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_CLK, 1);
}
void BOARD_SPI_SCK_L(void)
{
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_CLK, 0);
}
void BOARD_SPI_MISO_H(void)
{
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_MISO, 1);
}
void BOARD_SPI_MISO_L(void)
{
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_MISO, 0);
}
void BOARD_SPI_MOSI_H(void)
{
#ifdef SPI_SOFT_3LINE
    int ret;
    if (spiMosiMode == 0)
    {
        GPIO_InitTypeDef GPIO_InitStructure;
        GPIO_InitStructure.GPIO_Pin = BOARD_PIN_SPI_MOSI;           
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
        GPIO_Init(BOARD_PORT_SPI_MOSI, &GPIO_InitStructure);
    }
    spiMosiMode = 1;
#endif
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_MOSI, 1);
}
void BOARD_SPI_MOSI_L(void)
{
#ifdef SPI_SOFT_3LINE
    int ret;
    if (spiMosiMode == 0)
    {
        GPIO_InitTypeDef GPIO_InitStructure;
        GPIO_InitStructure.GPIO_Pin = BOARD_PIN_SPI_MOSI;           
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
        GPIO_Init(BOARD_PORT_SPI_MOSI, &GPIO_InitStructure);
    }
    spiMosiMode = 1;
#endif
    SN_GPIO_PIN_write(BOARD_GPIO_SPI_MOSI, 0);
}
uint8_t READ_BOARD_SPI_MISO(void)
{
#ifndef SPI_SOFT_3LINE
    return SN_GPIO_PIN_get(BOARD_GPIO_SPI_MISO);
#else
    int ret;
    if (spiMosiMode == 1)
    {
        GPIO_InitTypeDef GPIO_InitStructure;
        GPIO_InitStructure.GPIO_Pin = BOARD_PIN_SPI_MOSI;           
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;     
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
        GPIO_Init(BOARD_PORT_SPI_MOSI, &GPIO_InitStructure);
    }
    spiMosiMode = 0;
    ret = SN_GPIO_PIN_get(BOARD_GPIO_SPI_MOSI);
    return ret;
#endif
}

//---------------------------射频驱动IO部分---------------------
void RF_PAN3029_IRQ_H(void)
{
    SN_GPIO_PIN_write(RF_PAN3029_IRQ, 1);
}
void RF_PAN3029_IRQ_L(void)
{
    SN_GPIO_PIN_write(RF_PAN3029_IRQ, 0);
}
void RF_PAN3029_NRST_H(void)
{
    // SN_GPIO_PIN_write(RF_PAN3029_NRST, 1);
}
void RF_PAN3029_NRST_L(void)
{
    // SN_GPIO_PIN_write(RF_PAN3029_NRST, 0);
}
void RF_PAN3029_IO3_H(void)
{
    // SN_GPIO_PIN_write(RF_PAN3029_IO3, 1);
}
void RF_PAN3029_IO3_L(void)
{
    // SN_GPIO_PIN_write(RF_PAN3029_IO3, 0);
}
void RF_EXT_PA_RE_H(void)
{
    // SN_GPIO_PIN_write(RF_EXTPA_RE, 1);
}
void RF_EXT_PA_RE_L(void)
{
    // SN_GPIO_PIN_write(RF_EXTPA_RE, 0);
}
void RF_EXT_PA_TE_H(void)
{
    // SN_GPIO_PIN_write(RF_EXTPA_TE, 1);
}
void RF_EXT_PA_TE_L(void)
{
    // SN_GPIO_PIN_write(RF_EXTPA_TE, 0);
}
uint8_t READ_RF_PAN3029_IRQ(void)
{
    return SN_GPIO_PIN_get(RF_PAN3029_IRQ);
}
uint8_t READ_RF_PAN3029_IO11(void)
{
    return SN_GPIO_PIN_get(RF_PAN3029_IO11);
}
void RF_IRQHandler(void)
{
    if (READ_RF_PAN3029_IRQ())
    {
        gpioCallback(1);
    }
}
// BOARD_GPIOB
void myRadio_gpio_irq_init()
{
    SN_EXIT_set(RF_PAN3029_IRQ,GPIO_NOPULL,RF_IRQHandler,EXTI_TRIGGER_RISING,NVIC_PRIO_3);
}
void myRadio_gpio_init(RADIO_GPIO_CALLBACK cb)
{
    // GPIO_InitTypeDef  GPIO_InitStructure;
    
#if defined(SPI_HARD)    
        SN_SPI_IO_set(SPI_MOSI_PA0 , SPI_MISO_PA1 , SPI_SCK_PB0,  SPI_NSS_NULL );
        SN_SPI_MASTER_init(SPI_BAUD_PCLKDIV_8, SPI_MODE_0 , SPI_MSB );
        SN_SPI_IO_SOF_cs(SPI_SOF_CS_PB1);
#else

    GPIO_InitStructure.GPIO_Pin = BOARD_PIN_SPI_MOSI;           
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;      
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
    GPIO_Init(BOARD_PORT_SPI_MOSI, &GPIO_InitStructure);
#ifndef SPI_SOFT_3LINE
    GPIO_InitStructure.GPIO_Pin = BOARD_PIN_SPI_MISO;           
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;     
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
    GPIO_Init(BOARD_PORT_SPI_MISO, &GPIO_InitStructure);
#endif
    GPIO_InitStructure.GPIO_Pin = BOARD_PIN_SPI_CLK;            
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;      
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
    GPIO_Init(BOARD_PORT_SPI_CLK, &GPIO_InitStructure);
    BOARD_SPI_SCK_L();

#endif
    SN_GPIO_PIN_init(BOARD_GPIO_SPI_CSN , GPIO_MODE_OUTPUT ,GPIO_PULLUP ,GPIO_OUTPUT_PUSHPULL);

    SN_GPIO_PIN_init(RF_PAN3029_IRQ , GPIO_MODE_INPUT ,GPIO_NOPULL ,GPIO_OUTPUT_PUSHPULL);
    // SN_GPIO_PIN_init(RF_PAN3029_NRST , GPIO_MODE_OUTPUT ,GPIO_PULLUP ,GPIO_OUTPUT_PUSHPULL);
    // SN_GPIO_PIN_init(RF_PAN3029_IO3 , GPIO_MODE_INPUT ,GPIO_NOPULL ,GPIO_OUTPUT_PUSHPULL);
    SN_GPIO_PIN_init(RF_PAN3029_IO11 , GPIO_MODE_OUTPUT ,GPIO_PULLUP ,GPIO_OUTPUT_PUSHPULL);
    // SN_GPIO_PIN_init(RF_EXTPA_RE , GPIO_MODE_OUTPUT ,GPIO_PULLUP ,GPIO_OUTPUT_PUSHPULL);
    // SN_GPIO_PIN_init(RF_EXTPA_TE , GPIO_MODE_OUTPUT ,GPIO_PULLUP ,GPIO_OUTPUT_PUSHPULL);

    BOARD_SPI_NSS_H();
    RF_PAN3029_NRST_H();
    myRadio_gpio_irq_init();
    gpioCallback = cb;
}
uint8_t myRadioSpi_rwByte(uint8_t byteToWrite)
{
    uint16_t i = 0;
    uint8_t temp;
    temp = 0;   
#if defined(SPI_HARD)

    /* 等待发送数据寄存器为空 */
    while(std_spi_get_flag(SPI_FLAG_TXFE) != SPI_FLAG_TXFE);
    /* 发送数据 */ 
    std_spi_write_data(byteToWrite);
        //SPI1->DR = tx_data;
    /* 等待接收数据寄存器非空 */
    while(std_spi_get_flag(SPI_FLAG_RXFNE) != SPI_FLAG_RXFNE);
    /* 接收数据 */ 
    temp=std_spi_read_data();
#else
    BOARD_SPI_SCK_L();
    for(i = 0; i < 8; i ++)
    {
        if(byteToWrite & 0x80)
        {
            BOARD_SPI_MOSI_H();
        }
        else
        {
            BOARD_SPI_MOSI_L();
        } 

        byteToWrite <<= 1;

        BOARD_SPI_SCK_H();
        temp <<= 1;
        if(READ_BOARD_SPI_MISO())
        {
            temp ++; 
        }
        BOARD_SPI_SCK_L();
    }
#endif
	return temp;
}

void myRadioSpi_wBuffer(uint8_t* pData, uint8_t len)
{
    for (size_t i = 0; i < len; i++)
    {
        myRadioSpi_rwByte(pData[i]);
    }
    
}

void myRadioSpi_rBuffer(uint8_t* pData, uint8_t len)
{
    for (size_t i = 0; i < len; i++)
    {
        pData[i] = myRadioSpi_rwByte(0xff);
    }
}

