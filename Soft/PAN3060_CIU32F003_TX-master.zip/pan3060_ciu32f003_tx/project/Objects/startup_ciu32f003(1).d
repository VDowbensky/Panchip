.\objects\startup_ciu32f003.o: ..\Startup\arm\startup_ciu32f003.s
