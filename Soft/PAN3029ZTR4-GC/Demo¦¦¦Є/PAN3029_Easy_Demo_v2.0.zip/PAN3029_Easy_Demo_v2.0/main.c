/**********************************************************************************************
 * @note Copyright (C) 2023 Shanghai Panchip Microelectronics Co., Ltd. All rights reserved.
 *
 * @file main.c
 * @brief
 *
 * @history - V0.8, 2024-4
********************************************************************************************/
#include "stm32f0xx.h"
#include "delay.h"
#include "user.h"

#include "time.h"


#define  EnableMaster        GPIO_ReadInputDataBit(RF_MODE_PORT, RF_MODE_PIN)//����ѡ���

#define TX_LEN 10
#define RX_LEN 64
uint8_t tx_test_buf[TX_LEN] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
uint8_t rx_test_buf[RX_LEN] = {0};
uint16_t crc_value;
double Rssi_dBm; //�ź�ǿ��ָʾ
double Snr_value;
extern struct RxDoneMsg RxDoneParams;

void SysClock_48()
{
  RCC_PLLCmd(DISABLE);
  RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_12); // 48M
  RCC_PLLCmd(ENABLE);
  while (!RCC_GetFlagStatus(RCC_FLAG_PLLRDY))
    ;
  RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
}

void Tick_Configration()
{
  /* Setup SysTick Timer for 1ms interrupts ( not too often to save power ) */
  if (SysTick_Config(SystemCoreClock / 1000))
  {
    /* Capture error */
    while (1)
      ;
  }
}

void RCC_Configuration()
{
  /* Enable GPIO clock */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA | RCC_AHBPeriph_GPIOB | RCC_AHBPeriph_GPIOC | RCC_AHBPeriph_GPIOF, ENABLE);

  /* Enable peripheral Clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2 | RCC_APB1Periph_PWR, ENABLE);

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_SYSCFG, ENABLE);
}
void NVIC_Config()
{
  NVIC_InitTypeDef NVIC_InitStructure;
  EXTI_InitTypeDef EXTI_InitStructure;

  EXTI_ClearITPendingBit(EXTI_Line1);
  EXTI_InitStructure.EXTI_Line = EXTI_Line1;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);

  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource1);
	
  /* Enable and set EXTI0 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI0_1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPriority = 0x00;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

void HW_Int() // MCU��Χ��Դ��ʼ��
{

  SysClock_48();
  Tick_Configration();
  RCC_Configuration();
  GPIO_int();
  SPI2_Int();
  NVIC_Config();
}

void LedToggle(void)
{
  GPIO_WriteBit(LED1_PORT, LED1_PIN, Bit_RESET); // LED��˸
  HAL_Delay_nMs(50);
  GPIO_WriteBit(LED1_PORT, LED1_PIN, Bit_SET);
  HAL_Delay_nMs(50);
}

uint32_t tx_time = 1000;
/*
 * Manages the master operation
 */
void OnMaster(void)
{
  // tx first
  if (rf_single_tx_data(tx_test_buf, TX_LEN, &tx_time) != OK)
  {
    GPIO_WriteBit(LED1_PORT, LED1_PIN, Bit_SET); // LED��
  }
  while (rf_get_transmit_flag() == RADIO_FLAG_IDLE)
    ;
  rf_set_transmit_flag(RADIO_FLAG_IDLE);
  LedToggle(); // LED��˸
  
  rf_enter_single_timeout_rx(15000);
      
}

/*
 * Manages the slave operation
 */

void OnSlave(void)
{
	
  uint8_t i = 0;
  if (rf_get_recv_flag() == RADIO_FLAG_RXDONE)
  {
    rf_set_recv_flag(RADIO_FLAG_IDLE);
    Rssi_dBm = RxDoneParams.Rssi; // RSSI �Ĳ�����Χ��-60 ��-140
    Snr_value = RxDoneParams.Snr;
    for (i = 0; i < RxDoneParams.Size; i++)
    {
      rx_test_buf[i] = RxDoneParams.Payload[i];
    }
    rf_enter_single_timeout_rx(15000); //���½������ģʽ
    LedToggle();                       // LED��
  }
  // rxtimeout or rxerr flag
  if ((rf_get_recv_flag() == RADIO_FLAG_RXTIMEOUT) || (rf_get_recv_flag() == RADIO_FLAG_RXERR))
  {
    rf_set_recv_flag(RADIO_FLAG_IDLE);
    rf_enter_single_timeout_rx(15000); //���½������ģʽ
  }
	
}


int main(void)
{
  uint32_t ret = 0;
  HW_Int(); // MCU��ʼ��
  Delay_Ms(1);
  ret = rf_init();
	
  if (ret != OK)
  {
	 GPIO_SetBits(LED1_PORT,LED1_PIN);
    while (1)
      ;
  }	
  GPIO_ResetBits(LED1_PORT,LED1_PIN);
	
  rf_set_default_para(); //������Ƶ����
	
  if (EnableMaster == true)
  {
		
  }
  else
  {
    rf_enter_single_timeout_rx(15000);
  }

  while (1)
  {	 
   if (EnableMaster) 
    {
      OnMaster();//����
    }
    else
    {
      OnSlave(); //�ӻ�
    }
		
  }
		
}
