/*******************************************************************************
 * @note Copyright (C) 2020 Shanghai Panchip Microelectronics Co., Ltd. All rights reserved.
 *
 * @file main.c
 * @brief
 *
 * @history - V3.0, 2021-07-12
*******************************************************************************/
#include "hc32_ddl.h"
#include "radio.h"
#include "pan3028.h" 
#include "oled.h"
#include "display.h"

extern struct RxDoneMsg RxDoneParams;
uint32_t app_tx_mode = 0;
static uint16_t m_au16Adc1Value[ADC1_CH_COUNT];

void SysTick_IrqHandler(void)
{
	SysTick_IncTick();
}
/**
  * @brief  The application entry point.
  * @retval int
  */
int32_t main(void)
{
	uint32_t ret = 0;
	float bat_value = 0;

	BSP_CLK_Init();
	Timer4_Init(); 
	SysTick_Init(1000u);
	SysTick_IncTick();
	
	BSP_GPIO_Init();
	OLED_Init();
	RF_IRQ_Init();
	BSP_LED_Init();
	BSP_KEY_Init();
	Spi_Config();
	Uart_Config();
	AdcConfig();

	ADC_PollingSa(M4_ADC1, m_au16Adc1Value, ADC1_CH_COUNT, TIMEOUT_VAL);
	bat_value = ((float)m_au16Adc1Value[0u] * ADC_VREF * (1.500f)) / (float)ADC1_ACCURACY;

	if(bat_value > 3.5)
	{
		DDL_Printf("ADC12_IN10 voltage is %.4fV.\r\n",bat_value);
	}else
	{
		BAT_LED_ON();
	}

	if(TX_RX_SELECT == TX_SELECT)
	{
		app_tx_mode = 1;
	}

	ret = rf_init();
	if(ret != OK)
	{
		dis_err(" RF Init Fail");
		while(1);
	}	

	rf_set_default_para();
	rf_set_tx_mode(PAN3028_TX_CONTINOUS);
	rf_set_rx_mode(PAN3028_RX_CONTINOUS);
	show_menu();
	dis_init();
	OLED_Refresh_Gram();  

	if(app_tx_mode)
	{
		DDL_Printf("tx\r\n");
		rf_port.set_tx();
	}
	else
	{
		DDL_Printf("rx\r\n");
		rf_port.set_rx();
		rf_set_mode(PAN3028_MODE_RX);
	} 

	while(1){
		key_scan();
		key_event_process();
		process_rf_events();
	}	

}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
