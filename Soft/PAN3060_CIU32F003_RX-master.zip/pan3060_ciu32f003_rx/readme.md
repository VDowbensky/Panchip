## 简要

- 射频方案：PAN3060
- 无线频段：433MHz
- 主控方案：京中电华大电子CIU32F003
- 射频驱动SDK：[PAN3029_3060_DK_V1.0.1](https://bbs.panchip.com/forum.php?mod=viewthread&tid=8256&extra=page%3D1)

## 功能
该项目作为接收端，开启CAD接收，接收数据，并打印接收到的数据。CAD相关处理放在`radio\myRadio.c`文件中，接收到有效数据后，会通过回调函数返回到`User\main.c`主函数中，主函数中会打印接收到的数据。
上电后会将烧录口初始化为串口，作为日志打印，如果需要在线仿真需要先屏蔽串口初始化。

## 接收数据日志打印

```c
[2025-09-19 09:00:05.250]# RECV ASCII>
rf_process=3
IRQFlag=0x8
status:0
receive data:hello worl

[2025-09-19 09:00:06.186]# RECV ASCII>
Interval Window=0 Interval=0
restart cad Window=500 Interval=2000

[2025-09-19 09:00:06.310]# RECV ASCII>
rf_process=4

[2025-09-19 09:00:06.701]# RECV ASCII>
Window Window=0 Interval=1501

[2025-09-19 09:00:08.247]# RECV ASCII>
Interval Window=0 Interval=0
restart cad Window=500 Interval=2000
cad = 4= 1
gpioCad

[2025-09-19 09:00:08.386]# RECV ASCII>
rf_process=3
IRQFlag=0x8
status:0
receive data:hello worl

[2025-09-19 09:00:09.440]# RECV ASCII>
rf_process=3
IRQFlag=0x8
status:0
receive data:hello worl
```

## 代码说明
### 1、`radio\myRadio.c`
该`.c`文件封装了常用的射频操作函数，包括：

- `myRadio_init`：初始化射频模块
- `myRadio_abort`: 射频进入休眠状态
- `myRadio_cadReceiver`: 进入CAD接收状态，可以通过控制`window_ms`参数来控制接收窗口，窗口越大，接收成功率越高，但是功耗越大，`interval_ms`参数控制接收间隔，间隔越大，功耗越小，但是接收成功率越低。定义了定时器1来计时。
    - **window_ms**：CAD接收窗口
    - **interval_ms**：CAD接收间隔
- `myRadio_process`: 射频处理函数，用于处理射频接收和发送的中断，需放在主循环中调用

### 2、`radio\myRadio_gpio.c`
该`.c`文件封装了射频驱动的所有硬件的操作，比如中断触发、spi接口初始化等。

**注意事项：**

- spi的clk时钟频率不能超过`10MHz`，主频为`48MHz`，spi的分频最小只能是`8`
- spi片选脚使用的是软件cs控制