/************************************************************************************************/
/**
* @file               main.c
* @author             MCU Ecosystem Development Team
* @brief              ��ʾ��չʾ��SNģ���÷���
*                     
*
**************************************************************************************************
* @attention
* Copyright (c) CEC Huada Electronic Design Co.,Ltd. All rights reserved.
*
**************************************************************************************************
*/

/*------------------------------------------includes--------------------------------------------*/
#include "main.h"
#include "common.h"
#include "SN_GPIO.h"
#include "SN_ADC.h"
#include "SN_PWM.h"
#include "SN_EXIT.h"
#include "SN_TIM3_INIT.h"
#include "SN_TIM1_INIT.h"
#include "SN_UART.h"
#include "SN_FLASH.h"
#include "SN_RCC.h"
#include "SN_SPI.h"
#include "SN_DDQ.h"
#include "i2c_bsp.h"
#include "SN_STOP.h"
#include <stdio.h>
#include "myRadio.h"
/*------------------------------------------functions-------------------------------------------*/
  
uint16_t ADC_VAL = 0;
float MCU_VDD = 0;

void rfRx_callback(uint8_t status, rfRxPacket_ts packet)
{
    printf("status:%d\r\n", status);
    switch (status)
    {
        case RX_STA_SECCESS:
        {
            printf("receive data:%s\r\n", packet.payload);
            // RF_StopCad();
            // myRadio_receiver();
            // myRadio_restartCadReceiver();
        }
        break;
        case RX_STA_TIMEOUT:
        {
            // myRadio_receiver();
            myRadio_restartCadReceiver();
        }
        break;
        case RX_STA_PAYLOAD_ERROR:
        {
            // myRadio_receiver();
            myRadio_restartCadReceiver();
        }
        break;
        case TX_STA_SECCESS:
        {
			// myRadio_receiver();
            myRadio_cadReceiver(300, 1000);
        }
        break;
        default:
            break;
    }
}
uint32_t sendTimeout = 0;
int main(void)
{  
    SN_SYSCLK_set(SYSCLK_48MHZ);                  //����ϵͳʱ��Ϊ48MHZ
    std_delay_init();                             //��ʼ����ʱ������ʱ��ʹ�õδ�ʱ��ʵ�ֵģ�
    std_delayms(500);	
    SN_UART_init(UART1,921600, UART1_RX_PA2, UART1_TX_PB6); //��ʼ������
    myRadio_init(0, rfRx_callback);
    myRadio_cadReceiver(500, 2000);
    // myRadio_receiver();
    printf("power on");
    while(1){
		std_delayms(1);		
		// SN_ADC_start();		                        //��ʱ�����SN_ADC_star()����ѯ����			
		// ADC_VAL = SN_ADC_Get_float(0);            //PA7ͨ����ѹֵ
		// MCU_VDD = SN_ADC_MCU_VDD();               //��ȡMCU�ĵ�ǰvdd��ѹ
        if (sendTimeout++ > 1000)
        {
            sendTimeout = 0;
            // myRadio_transmitArray("hello world", 10);
        }
        
		myRadio_process();
	}
}
		





