/*******************************************************************************
 *  Copyright (C) 2021 Shanghai Panchip Microelectronics Co., Ltd.
 *  All rights reserved.
 *
 *  @file:  pro_config.c
 *  @brief: Global configuration file
 *  @history: - V1.0, 2021-12-13
 *
 *******************************************************************************/
#ifndef PRO_CONFIG_H
#define PRO_CONFIG_H

#include "pan3028.h"
#include "userlog.h"

/*RF config*/
#define PAN_CFG_RF_BW                        BW_250K
#define PAN_CFG_RF_SF                        SF_7
#define PAN_CFG_RF_FREQ                      470000000
#define PAN_CFG_RF_CR                        CODE_RATE_45

/*network config*/
#define PAN_CFG_NET_SEND_TIMEOUT             1000                //���ͳ�ʱʱ��
#define PAN_CFG_NET_CONFLICT_TIMEOUT         3                   //����ǰ����źų�ͻ�Ĵ���
#define PAN_CFG_NET_TTL_MAX                  7                   //���ݰ����ڵ���

/*memery config*/
#define PAN_CFG_MEM_UART_CACHE               256                 //Debug���ڽ��ջ�������С

/*log config*/
#define PAN_CFG_LOG_LEVEL                    LOG_LEVEL_DEBUG     //��־��ӡ����

#endif //PRO_CONFIG_H
