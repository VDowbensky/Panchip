C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Output/Debug/OS_ThreadSafe.o: \
 C:\Work\TestProjects\J-Trace_PRO_CortexM_Tutorial\BoardSupport\Segger\STM32F407_CortexM_TraceReferenceBoard\Setup\OS_ThreadSafe.c \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/RTOS.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/string.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/__crossworks.h \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/OS_Config.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/__libc.h
