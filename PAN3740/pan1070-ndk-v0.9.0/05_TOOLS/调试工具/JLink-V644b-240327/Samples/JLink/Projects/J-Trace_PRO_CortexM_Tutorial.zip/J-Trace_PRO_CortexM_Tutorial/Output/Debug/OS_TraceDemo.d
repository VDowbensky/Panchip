C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Output/Debug/OS_TraceDemo.o: \
 C:\Work\TestProjects\J-Trace_PRO_CortexM_Tutorial\Application\OS_TraceDemo.c \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/RTOS.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/string.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/__crossworks.h \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/OS_Config.h \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/BSP.h
