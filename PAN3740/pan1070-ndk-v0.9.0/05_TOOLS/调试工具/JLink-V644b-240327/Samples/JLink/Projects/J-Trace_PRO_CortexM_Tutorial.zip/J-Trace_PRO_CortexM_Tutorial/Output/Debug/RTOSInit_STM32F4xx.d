C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Output/Debug/RTOSInit_STM32F4xx.o: \
 C:\Work\TestProjects\J-Trace_PRO_CortexM_Tutorial\BoardSupport\Segger\STM32F407_CortexM_TraceReferenceBoard\Setup\RTOSInit_STM32F4xx.c \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/RTOS.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/string.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/__crossworks.h \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/OS_Config.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/SEGGER/SEGGER_SYSVIEW.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/SEGGER/SEGGER.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/stdarg.h \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/Global.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/DeviceSupport/stm32f4xx.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/CoreSupport/core_cm4.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/stdint.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/CoreSupport/cmsis_version.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/CoreSupport/cmsis_compiler.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/CoreSupport/cmsis_gcc.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/CoreSupport/mpu_armv7.h \
 BoardSupport/Segger/STM32F407_CortexM_TraceReferenceBoard/DeviceSupport/system_stm32f4xx.h \
 C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Inc/JLINKMEM.h
