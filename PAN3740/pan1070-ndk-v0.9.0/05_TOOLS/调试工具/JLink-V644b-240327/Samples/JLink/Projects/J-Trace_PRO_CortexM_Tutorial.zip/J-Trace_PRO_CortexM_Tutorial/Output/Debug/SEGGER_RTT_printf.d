C:/Work/TestProjects/J-Trace_PRO_CortexM_Tutorial/Output/Debug/SEGGER_RTT_printf.o: \
 C:\Work\TestProjects\J-Trace_PRO_CortexM_Tutorial\BoardSupport\Segger\STM32F407_CortexM_TraceReferenceBoard\SEGGER\SEGGER_RTT_printf.c \
 C:\Work\TestProjects\J-Trace_PRO_CortexM_Tutorial\BoardSupport\Segger\STM32F407_CortexM_TraceReferenceBoard\SEGGER\SEGGER_RTT.h \
 C:\Work\TestProjects\J-Trace_PRO_CortexM_Tutorial\BoardSupport\Segger\STM32F407_CortexM_TraceReferenceBoard\SEGGER\SEGGER_RTT_Conf.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/stdlib.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/__crossworks.h \
 C:/Program\ Files\ (x86)/SEGGER/SEGGER\ Embedded\ Studio\ for\ ARM\ 4.12/include/stdarg.h
